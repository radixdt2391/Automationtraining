package Test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class temp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int time = 1;
		while(time<50000) {
			System.out.println(time);
			time++;
		}
	}

}
