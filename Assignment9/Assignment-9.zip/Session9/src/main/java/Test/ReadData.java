package Test;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadData {
	
	static XSSFWorkbook workbook;
	static XSSFSheet sheet;
	static int rowcount;
	static int cellcount;
	
public static int Excelrowcount (String FileName) throws IOException {
		
		FileInputStream input = new FileInputStream("Test.xlsx");
		workbook = new XSSFWorkbook(input);
		sheet = workbook.getSheet(FileName);
		rowcount = sheet.getLastRowNum();
		
		return rowcount;
	}
	
	public static String Excelcelldata (int datarow, String column) throws IOException {
		
		cellcount = sheet.getRow(0).getLastCellNum();
		
		String cellvalue = null;
		for (int j=0; j<cellcount; j++) {
			if (sheet.getRow(0).getCell(j).toString().equals(column)) {
				System.out.println(sheet.getRow(datarow).getCell(j).toString());
			cellvalue = sheet.getRow(datarow).getCell(j).toString();
			}
		}
			return cellvalue;
	}


}
