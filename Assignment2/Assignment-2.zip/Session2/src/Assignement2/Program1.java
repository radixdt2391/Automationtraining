package Assignement2;

public class Program1 {
	
	 public void addition(int a, int b) {
		   int Result = a+b;
		    System.out.println("Addition" + " " + Result);
	 }
    
	 public void Subtraction(int a, int b) {
		 int Res = a-b;
		 System.out.println("Subtraction" + " " + Res);
		  
	 }
	 
	 public void multiplication(int a, int b) {
		 
		 System.out.println("multiplication" + " " + a*b);
	 }
	 
	 public void division(float a, float b) {
		 
		System.out.println("division" + " " + a/b); 
	 }
	 
	public static void main(String[] args) {
	  Program1 Test = new Program1();
	  Test.addition(10, 20);
	  Test.Subtraction(20, 10);
	  Test.multiplication(10, 2);
	  Test.division(10f, 50f);
	}
}
