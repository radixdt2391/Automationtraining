package Assignement2;

import java.time.Year;
import java.util.Scanner;

public class Program4 {

	public static void main(String[] args) {
		
		 Year currentYear = Year.now();
		 int thisYear = currentYear.getValue();
		
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Job Started Year");
		int joinYear = sc.nextInt();
		
		System.out.println("Enter your Age");
		int birthYear = sc.nextInt();
		
		int totalexpi = thisYear - joinYear;
		
		System.out.println("Total Exp is " + totalexpi + " " + "And Age is " + birthYear);
		
				
        if (totalexpi < 22 && birthYear <= 40) {
             System.out.println("You are eligible");
        }
        else 
        	System.out.println("Invalid");
        }	
        
	}


