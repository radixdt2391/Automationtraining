package Assignement2;

import java.util.Scanner;

public class Program2 {

	public static void main(String[] args) {
		
		
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Enter object");
        String s1 = sc.nextLine(); 
        
        System.out.println("Enter Class");
        String s2 = sc.nextLine();
     
        
        System.out.println(s1.equals(s2));
        System.out.println(s1.equalsIgnoreCase(s2));
        System.out.println(s1.concat(" ").concat(s2));
	}

}