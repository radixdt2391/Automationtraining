package Assignement2;

import java.util.Arrays;
import java.util.Scanner;

public class Program3 {

	public static void main(String[] args) {
		
       Scanner sc = new Scanner (System.in);
     System.out.println("Enter Firstname");
       
          String F1 = sc.nextLine().toLowerCase();
          String F2 = sc.nextLine();
          String F3 = sc.nextLine();
          String F4 = sc.nextLine();
          String F5 = sc.nextLine();
       
               System.out.println("Enter Lastname");
       
          String L1 = sc.nextLine(); 
          String L2 = sc.nextLine(); 
          String L3 = sc.nextLine();
          String L4 = sc.nextLine();
          String L5 = sc.nextLine();
      
                System.out.println("Full Name");
                
           System.out.println(F1.concat(" ").concat(L1));
           System.out.println(F2.concat(" ").concat(L2));
           System.out.println(F3.concat(" ").concat(L3));
           System.out.println(F4.concat(" ").concat(L4));
           System.out.println(F5.concat(" ").concat(L5));
           
         String Fullname1 = F1.concat(" ").concat(L1).toLowerCase();
         String Fullname2 = F2.concat(" ").concat(L2);
         String Fullname3 = F3.concat(" ").concat(L3);
         String Fullname4 = F4.concat(" ").concat(L4);
         String Fullname5 = F5.concat(" ").concat(L5);
        
        System.out.println("Names in Alphabetical Order");
        
        String arr[] = {Fullname1,Fullname2,Fullname3,Fullname4,Fullname5};
// Sorts arr[] in ascending order
Arrays.sort(arr);
System.out.println(Arrays.toString(arr));
   
	}
}
