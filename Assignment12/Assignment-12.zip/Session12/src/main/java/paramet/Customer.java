package paramet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import TestPack.readdata;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Customer {

	public static WebDriver driver;

	public static void capture (WebDriver driver, String filename) throws IOException {
		File scrshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrshot, new File(filename + "png"));
	}

	public static void browseropen() {
		
		ChromeOptions handlingSSL = new ChromeOptions();
		handlingSSL.setAcceptInsecureCerts(true);
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver(handlingSSL); //for chrome browser
		driver.manage().window().maximize();
	}
	
	public String getXPath(String key,String Propertiesfile) throws IOException {
		File propfile = new File (Propertiesfile);
		FileInputStream file = new FileInputStream(propfile);
		Properties Prop = new Properties();
		Prop.load(file);
		return Prop.getProperty(key);
	}

	public void loginpage (String Propertiesfile, String filename, String sheetname) throws IOException {
	
		driver.get("https://www.ops-s3.radixdev79.com/admin");
		WebControl.ManageTextbox(driver, "admin", getXPath("adminuser",Propertiesfile));
		WebControl.ManageTextbox(driver, "Admin095", getXPath("adminpassword", Propertiesfile));
		WebControl.ManageClick(driver, getXPath("login", Propertiesfile));
	
		Customer.capture(driver, "Login Page");	
	}
	
	public void adduser (String Propertiesfile, String filename, String sheetname) throws IOException {
		
		driver.navigate().to("https://www.ops-s3.radixdev79.com/admin/user_listing.php");
		int Rowcount = DataRead.Excelrowdata(sheetname, filename);
		System.out.println("Print row count " + Rowcount);
		
		
		for(int i=1;i<=Rowcount;i++) {
		
		WebControl.ManageClick(driver, getXPath("addnew",Propertiesfile));
		
		WebControl.ManageTextbox(driver, DataRead.Excelcelldata(i, "First Name"), getXPath("firstname", Propertiesfile));

		WebControl.ManageTextbox(driver, DataRead.Excelcelldata(i, "Last Name"), getXPath("lastname",Propertiesfile));

		WebControl.ManageTextbox(driver, DataRead.Excelcelldata(i, "Email"), getXPath("email",Propertiesfile));
	
		WebControl.ManageTextbox(driver, DataRead.Excelcelldata(i, "Password"), getXPath("password",Propertiesfile));
	
		WebControl.ManageTextbox(driver, DataRead.Excelcelldata(i, "Phone Number"), getXPath("phonenumber", Propertiesfile));
	
		WebControl.ManageTextbox(driver, DataRead.Excelcelldata(i, "Username"), getXPath("username",Propertiesfile));
		
		WebControl.ManageDropdown(driver, "2", getXPath("usergroup", Propertiesfile));
		
		Customer.capture(driver, "add-user");
		
		WebControl.ManageTextbox(driver, DataRead.Excelcelldata(i, "Address 1"), getXPath("add1", Propertiesfile));
	
		//WebControl.manageclick(driver, getXPath("state"));
		WebControl.bootstrapDropdown(driver, DataRead.Excelcelldata(i, "State"), getXPath("state", Propertiesfile), getXPath("statevalue", Propertiesfile));
		
		WebControl.ManageTextbox(driver, DataRead.Excelcelldata(i, "City"), getXPath("city", Propertiesfile));
	
		WebControl.ManageTextbox(driver, DataRead.Excelcelldata(i, "Zip Code"), getXPath("zipcode", Propertiesfile));
	
		boolean checkbox = driver.findElement(By.xpath(getXPath("checkbox", Propertiesfile))).isSelected();
		if(!checkbox) {
		WebControl.ManageClick(driver,getXPath("checkbox",Propertiesfile));
		}
		
		WebControl.ManageClick(driver, getXPath("radio",Propertiesfile));
		
		WebControl.ManageTextbox(driver, DataRead.Excelcelldata(i, "Text area"), getXPath("textarea",Propertiesfile));
	
		boolean payon = driver.findElement(By.xpath(getXPath("payonaccount",Propertiesfile))).isEnabled();
			if(payon==true) {
			WebControl.ManageClick(driver, getXPath("payonaccount",Propertiesfile));
			}
			
		boolean payonlimit = driver.findElement(By.xpath(getXPath("payonimit",Propertiesfile))).isDisplayed();
			if(payonlimit==true) {
			WebControl.ManageTextbox(driver, DataRead.Excelcelldata(i, "Pay On Limit"), getXPath("payonimit",Propertiesfile));
		}
		
		WebControl.ManageClick(driver, getXPath("saveandback",Propertiesfile));
		
		Customer.capture(driver, "user-added");
		}
	}
	
	public void edituser(String Propertiesfile, String filename, String sheetname) throws IOException {
		
		WebControl.ManageClick(driver, getXPath("action", Propertiesfile));

		WebControl.ManageClick(driver, getXPath("edit", Propertiesfile));
		
		int EditRow = DataRead.Excelrowdata(sheetname, filename);
		for(int i=1;i<=EditRow;i++) {
		
		WebControl.ManageTextbox(driver, DataRead.Excelcelldata(i, "First Name"), getXPath("firstname",Propertiesfile));

		WebControl.ManageTextbox(driver, DataRead.Excelcelldata(i, "Last Name"), getXPath("lastname",Propertiesfile));

		WebControl.ManageTextbox(driver, DataRead.Excelcelldata(i, "Phone Number"), getXPath("phonenumber",Propertiesfile));

		Customer.capture(driver, "edit-user");
		
		WebControl.ManageClick(driver, getXPath("saveandback",Propertiesfile));
		}
	}
	
	public void deleteuser(String Propertiesfile, String filename, String sheetname) throws IOException {
		WebControl.ManageClick(driver, getXPath("action",Propertiesfile));
		
		WebControl.ManageClick(driver, getXPath("delete",Propertiesfile));
		int time = 1;
		while(time<50000) {
			try {
			WebControl.ManageClick(driver, getXPath("deleteok",Propertiesfile));
			break;
			}
			catch (Exception e) {
			}
			time++;
		}
		driver.navigate().refresh();
		
		Customer.capture(driver, "delete-user");
	}

	public void closebrowser() {
		driver.close();
	}
	
}
