package paramet;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class WebControl {
	

	public static void ManageTextbox(WebDriver driver, String value, String XPath) {
		WebElement input = driver.findElement(By.xpath(XPath));
		if(input.getAttribute("value")!=null) {
			input.clear();
		}
		input.sendKeys(value);
	}
	
	public static void ManageClick (WebDriver driver, String Xpath) {
		WebElement clicks = driver.findElement(By.xpath(Xpath));
		clicks.click();	
	}
	
	public static void ManageDropdown (WebDriver driver, String Value, String XPath) {
		Select dropdown = new Select (driver.findElement(By.xpath(XPath)));
		dropdown.selectByVisibleText(Value);
	}
	
	public static void bootstrapDropdown (WebDriver driver, String Value, String ClickXapth, String DDXPath) {
		ManageClick(driver, ClickXapth);
		List <WebElement> dropdown = driver.findElements(By.xpath(DDXPath));
		for(int i=0; i<dropdown.size(); i++) {
			System.out.println("Print state: " +  dropdown);
			if(dropdown.get(i).getText().toString().equals(Value)) {
				((WebElement) dropdown.get(i)).click();
				break;
 			}
		}
	}

}
