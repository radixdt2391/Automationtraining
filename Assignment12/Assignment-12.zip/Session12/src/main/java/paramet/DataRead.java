package paramet;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DataRead {

	static XSSFWorkbook workbook;
	static XSSFSheet sheet;
	static int rowcount;
	static int cellcount;
	
	public static int Excelrowdata (String Filename,String filepath) throws IOException {
		
		FileInputStream inputs = new FileInputStream(filepath);
		workbook = new XSSFWorkbook(inputs);
		sheet = workbook.getSheet(Filename);
		rowcount = sheet.getLastRowNum();
		
		return rowcount;
	}
	
	public static String Excelcelldata (int row, String cell) {
		
		cellcount = sheet.getRow(0).getLastCellNum();
		
		String cellvalue = null;
		for(int i=0; i<cellcount; i++) {
			if(sheet.getRow(0).getCell(i).toString().equals(cell)) {
			cellvalue = sheet.getRow(row).getCell(i).toString();
			}
		}
		return cellvalue;
	}
	
	
}
