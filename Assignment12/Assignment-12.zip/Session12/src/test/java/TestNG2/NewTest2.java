package TestNG2;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.annotations.Parameters;


import com.beust.jcommander.Parameter;

import paramet.Customer;

public class NewTest2 {
	
	Customer websitecustomer = new Customer();
	String Propertiesfile, filename, sheetname;
	
  @BeforeTest
  public void browser() {
	  Customer.browseropen();
  }
  
  @BeforeMethod
  @Parameters({"Propertiesfile", "filename", "sheetname"})
  public void Configuration(String Propertiesfile, String filename, String sheetname) throws IOException {
	  
	  this.filename=filename;
	  this.Propertiesfile=Propertiesfile;
	  this.sheetname=sheetname;
  }
  
  @Test
  public void login() throws IOException {
	  websitecustomer.loginpage(Propertiesfile,filename, sheetname);
  }
  
  @Test
  public void Adduser() throws IOException {
	  websitecustomer.adduser(Propertiesfile,filename, sheetname);
  }
  
  @Test
  public void Edituser() throws IOException {
	  websitecustomer.edituser(Propertiesfile, filename, sheetname);
  }
  
  @Test
  public void Deleteuser() throws IOException {
	  websitecustomer.deleteuser(Propertiesfile, filename, sheetname);
  }
  
  @AfterMethod
  public void curd() {
	  System.out.println("aftermethod");
  }
  
  @AfterTest
  public void Browserclose() {
	  websitecustomer.closebrowser();
  }
}
