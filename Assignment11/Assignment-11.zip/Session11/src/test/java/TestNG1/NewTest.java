package TestNG1;

import java.io.IOException;

import org.testng.annotations.Test;

import TestPack.UserAdd;


public class NewTest {
	
	UserAdd user = new UserAdd();
	
	@Test(priority=1, groups= {"configuration"})
	public void browserload () {
		UserAdd.browseropen();
  }
	
	@Test(priority=2, groups= {"configuration"})
	public void login() throws IOException {
		user.loginpage();
  }
	
	@Test(priority=3, groups= {"crud"})
	public void useradd() throws IOException {
		user.adduser();
  }
	
	@Test(priority=4, groups= {"crud"})
	public void useredit() throws IOException {
		user.edituser();
  }
	
	
	@Test(priority=5, groups= {"crud"})
	public void userdelete() throws IOException {
		user.deleteuser();
  }
	
	@Test
	public void browserclose() {
		user.closebrowser();
  }
	
}
