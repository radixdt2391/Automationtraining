package TestPack;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class readdata {

	static XSSFWorkbook workbook;
	static XSSFSheet sheet;
	static int rowcount;
	static int cellcount;
	
	public static int Excelrowdata (String Filename) throws IOException {
		
		FileInputStream inputs = new FileInputStream("TestNG.xlsx");
		workbook = new XSSFWorkbook(inputs);
		sheet = workbook.getSheet(Filename);
		rowcount = sheet.getLastRowNum();
		
		return rowcount;
	}
	
	public static String Excelcelldata (int row, String cell) {
		
		cellcount = sheet.getRow(0).getLastCellNum();
		
		String cellvalue = null;
		for(int i=0; i<cellcount; i++) {
			if(sheet.getRow(0).getCell(i).toString().equals(cell)) {
			cellvalue = sheet.getRow(row).getCell(i).toString();
			}
		}
		return cellvalue;
	}
	
}
