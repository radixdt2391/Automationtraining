package TestPack;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class UserAdd {

	public static WebDriver driver;

	public static void capture (WebDriver driver, String filename) throws IOException {
		File scrshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrshot, new File(filename + "png"));
	}

	public static void browseropen() {
		
		ChromeOptions handlingSSL = new ChromeOptions();
		handlingSSL.setAcceptInsecureCerts(true);
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver(handlingSSL); //for chrome browser
		driver.manage().window().maximize();
	}
	
	public String getXPath(String key) throws IOException {
		File propfile = new File ("src/test/resources/file.properties");
		FileInputStream file = new FileInputStream(propfile);
		Properties Prop = new Properties();
		Prop.load(file);
		return Prop.getProperty(key);
	}

	public void loginpage () throws IOException {
	
		driver.get("https://www.ops-s3.radixdev79.com/admin");
		WebControl.managetextbox(driver, "admin", getXPath("adminuser"));
		WebControl.managetextbox(driver, "Admin095", getXPath("adminpassword"));
		WebControl.manageclick(driver, getXPath("login"));
	
		UserAdd.capture(driver, "Login Page");	
	}
	
	public void adduser () throws IOException {
		
		driver.navigate().to("https://www.ops-s3.radixdev79.com/admin/user_listing.php");
		int Rowcount = readdata.Excelrowdata("Addcustom");
		System.out.println("Print row count " + Rowcount);
		
		for(int i=1;i<=Rowcount;i++) {
		
		WebControl.manageclick(driver, getXPath("addnew"));
		
		WebControl.managetextbox(driver, readdata.Excelcelldata(i, "First Name"), getXPath("firstname"));

		WebControl.managetextbox(driver, readdata.Excelcelldata(i, "Last Name"), getXPath("lastname"));

		WebControl.managetextbox(driver, readdata.Excelcelldata(i, "Email"), getXPath("email"));
	
		WebControl.managetextbox(driver, readdata.Excelcelldata(i, "Password"), getXPath("password"));
	
		WebControl.managetextbox(driver, readdata.Excelcelldata(i, "Phone Number"), getXPath("phonenumber"));
	
		WebControl.managetextbox(driver, readdata.Excelcelldata(i, "Username"), getXPath("username"));
		
		WebControl.managedropdown(driver, "2", getXPath("usergroup"));
		
		UserAdd.capture(driver, "add-user");
		
		WebControl.managetextbox(driver, readdata.Excelcelldata(i, "Address 1"), getXPath("add1"));
	
		WebControl.manageclick(driver, getXPath("state"));
		WebControl.bootstrapDD(driver, readdata.Excelcelldata(i, "State"), getXPath("statevalue"));
		
		WebControl.managetextbox(driver, readdata.Excelcelldata(i, "City"), getXPath("city"));
	
		WebControl.managetextbox(driver, readdata.Excelcelldata(i, "Zip Code"), getXPath("zipcode"));
	
		boolean checkbox = driver.findElement(By.xpath(getXPath("checkbox"))).isSelected();
		if(!checkbox) {
		WebControl.manageclick(driver,getXPath("checkbox"));
		}
		
		WebControl.manageclick(driver, getXPath("radio"));
		
		WebControl.managetextbox(driver, readdata.Excelcelldata(i, "Text area"), getXPath("textarea"));
	
		boolean payon = driver.findElement(By.xpath(getXPath("payonaccount"))).isEnabled();
			if(payon==true) {
			WebControl.manageclick(driver, getXPath("payonaccount"));
			}
			
		boolean payonlimit = driver.findElement(By.xpath(getXPath("payonimit"))).isDisplayed();
			if(payonlimit==true) {
			WebControl.managetextbox(driver, readdata.Excelcelldata(i, "Pay On Limit"), getXPath("payonimit"));
		}
		
		WebControl.manageclick(driver, getXPath("saveandback"));
		
		UserAdd.capture(driver, "user-added");
		}
	}
	
	public void edituser() throws IOException {
		
		WebControl.manageclick(driver, getXPath("action"));

		WebControl.manageclick(driver, getXPath("edit"));
		
		int EditRow = readdata.Excelrowdata("editcustom");
		for(int i=1;i<=EditRow;i++) {
		
		WebControl.managetextbox(driver, readdata.Excelcelldata(i, "First Name"), getXPath("firstname"));

		WebControl.managetextbox(driver, readdata.Excelcelldata(i, "Last Name"), getXPath("lastname"));

		WebControl.managetextbox(driver, readdata.Excelcelldata(i, "Phone Number"), getXPath("phonenumber"));

		UserAdd.capture(driver, "edit-user");
		
		WebControl.manageclick(driver, getXPath("saveandback"));
		}
	}
	
	public void deleteuser() throws IOException {
		WebControl.manageclick(driver, getXPath("action"));
		
		WebControl.manageclick(driver, getXPath("delete"));
		int time = 1;
		while(time<50000) {
			try {
			WebControl.manageclick(driver, getXPath("deleteok"));
			break;
			}
			catch (Exception e) {
			}
			time++;
		}
		driver.navigate().refresh();
		
		UserAdd.capture(driver, "delete-user");
	}

	public void closebrowser() {
		driver.close();
	}
	
}
