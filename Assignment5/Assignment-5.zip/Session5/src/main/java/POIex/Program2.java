package POIex;

import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Program2 {

	public static void main(String[] args) throws IOException {
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("Product");
		
		Object[][] Product = {{"TestCase ID", "Dec", "Type", "Result"},
								{001, "Add 'Category Group' with all fields.", "Smoke", "Pass"}, 
								{002, "Add 'Attribute-wise stock'", "Functional", "Fail"}, 
								{003, "Add Text Area master option.", "Smoke","Pass"}};
		
		int rows=Product.length;
		int cols=Product[0].length;
		
		System.out.println(rows);
		System.out.println(cols);
		
		for(int i=0;i<rows;i++) {
			XSSFRow row = sheet.createRow(i);
			
			for(int j=0;j<cols;j++) {
				XSSFCell cell = row.createCell(j);
				Object Test = Product[i][j];
					if(Test instanceof String) {
						cell.setCellValue((String)Test);
						}
					if(Test instanceof Integer){
						cell.setCellValue((Integer)Test);
						}	
			}
		}
		FileOutputStream out = new FileOutputStream("Program2.xlsx");
		workbook.write(out);
		out.close();
		
		System.out.println("Success....");

	}

}
