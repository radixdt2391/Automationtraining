package Main;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;
import net.bytebuddy.agent.builder.AgentBuilder.CircularityLock.Global;

public class Addquote {
	
	static WebDriver driver;

	public static void main(String[] args) throws IOException, InterruptedException {
		
		ChromeOptions handlingSSL = new ChromeOptions();
		handlingSSL.setAcceptInsecureCerts(true);
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver(handlingSSL); //for chrome browser

		
		driver.manage().window().maximize();
		driver.get("https://www.ops-s3.radixdev79.com");
		driver.navigate().to("https://www.ops-s3.radixdev79.com/quote_create.php");	
		
		File propfile = new File ("src/test/resources/File.properties");
		FileInputStream file = new FileInputStream(propfile);
		Properties Prop = new Properties();
		Prop.load(file);
	
		int Rowcount = Class2.Excelrowcount();
		System.out.println("Print row count " + Rowcount);
		
		
		for(int i=1;i<=Rowcount;i++) {
			
		WebElement title = driver.findElement(By.xpath(Prop.getProperty("Title")));
		title.sendKeys((Class2.Excelcelldata(i, "Quote Title")));

		if (i==1) {
			WebElement existing = driver.findElement(By.xpath(Prop.getProperty("Existing")));
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", existing);		
			} else {
			WebElement custom = driver.findElement(By.xpath(Prop.getProperty("Custom")));
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", custom);
			}
		
		driver.findElement(By.xpath(Prop.getProperty("SelectProduct"))).click();
		List <WebElement> dropdown = driver.findElements(By.xpath(Prop.getProperty("Dropdown")));

			for(int i1=0; i1<dropdown.size();i1++) {
				if (dropdown.get(i1).getText().equals((Class2.Excelcelldata(i, "Select Product")))) {
					((WebElement) dropdown.get(i1)).click();
					break;
				}
			}
		Thread.sleep(2000);
		driver.findElement(By.xpath(Prop.getProperty("Size"))).click();
		List <WebElement> sizedropdown = driver.findElements(By.xpath(Prop.getProperty("Dropdown")));
		for(int j=0; j<sizedropdown.size(); j++) {
			if (sizedropdown.get(j).getText().equals((Class2.Excelcelldata(i, "Size")))) {
				((WebElement) sizedropdown.get(j)).click();
				break;
				}
		}
		
//		try {
//		WebElement quantity = driver.findElement(By.xpath(Prop.getProperty("Quantity1")));
//		quantity.clear();
//		quantity.sendKeys((Class2.Excelcelldata(i, "Quantity 1")));
//		} 
//		catch (StaleElementReferenceException e) {		
//		}
		
		/*Thread.sleep(2000);
		WebElement upload = driver.findElement(By.xpath(Prop.getProperty("UploadFile")));
		int time = 0;
		while (time < 20) {
			if(upload.isDisplayed()) {
			//upload.sendKeys("/home/vidhi.chauhan/eclipse-workspace/Session8/Image");
			executeScript("arguments[0].style.display='block';", upload); // Ensure it's visible
			upload.sendKeys("/home/vidhi.chauhan/eclipse-workspace/Session8/Image");
			}
			time++;
		}*/
		
		try {
		driver.findElement(By.xpath(Prop.getProperty("Coating"))).click();
		List <WebElement> coating = driver.findElements(By.xpath(Prop.getProperty("Dropdown")));
			for(int coat=0; coat<coating.size();coat++) {
				if (coating.get(coat).getText().equals((Class2.Excelcelldata(i, "Coating")))) {
					((WebElement) coating.get(coat)).click();
					break;
					}
				}
			}
			catch (StaleElementReferenceException e) {
			}
		
		boolean checkbox = driver.findElement(By.xpath(Prop.getProperty("Attribute"))).isSelected();
		  if (!checkbox) {
			   WebElement attribute = driver.findElement(By.xpath(Prop.getProperty("Attribute")));
			   attribute.click();  // Click to select the checkbox
          }
		
		WebElement textarea = driver.findElement(By.xpath(Prop.getProperty("AddDetails")));
		textarea.sendKeys(Class2.Excelcelldata(i, "Additional Details"));
		
		WebElement savecont = driver.findElement(By.xpath(Prop.getProperty("AnotherProduct")));
		savecont.click();
		Thread.sleep(2000);
		
		}
	}
}
