package Main;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Addcustomer {

	static WebDriver driver;
	
	public static void main(String[] args) throws IOException {
		
		ChromeOptions handlingSSL = new ChromeOptions();
		handlingSSL.setAcceptInsecureCerts(true);
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver(handlingSSL); //for chrome browser

		driver.manage().window().maximize();
		driver.get("https://www.ops-s3.radixdev79.com/admin");
		
		WebElement login = driver.findElement(By.xpath("//input[@name='username']"));
		login.sendKeys("admin");
		WebElement password = driver.findElement(By.xpath("//input[@id='password']"));
		password.sendKeys("Admin095");
		WebElement click = driver.findElement(By.xpath("//button[@type='submit']"));
		click.click();
		
		driver.navigate().to("https://www.ops-s3.radixdev79.com/admin/user_listing.php");
		
		File propfile = new File ("src/test/resources/File.properties");
		FileInputStream file = new FileInputStream(propfile);
		Properties Prop = new Properties();
		Prop.load(file);
		
		int Rowcount = Class2.Excelrowcount();
		System.out.println("Print row count " + Rowcount);
		
		for(int i=1;i<=Rowcount;i++) {
			
		WebElement add = driver.findElement(By.xpath(Prop.getProperty("addnew")));
		add.click();
		
		WebElement Fname = driver.findElement(By.xpath(Prop.getProperty("firstname")));
		Fname.sendKeys((Class2.Excelcelldata(i, "First Name")));
		
		WebElement Lname = driver.findElement(By.xpath(Prop.getProperty("lastname")));
		Lname.sendKeys((Class2.Excelcelldata(i, "Last Name")));
		
		WebElement email = driver.findElement(By.xpath(Prop.getProperty("email")));
		email.sendKeys((Class2.Excelcelldata(i, "Email")));
		
		WebElement Password = driver.findElement(By.xpath(Prop.getProperty("password")));
		Password.sendKeys((Class2.Excelcelldata(i, "Password")));
		
		WebElement phone = driver.findElement(By.xpath(Prop.getProperty("phonenumber")));
		phone.sendKeys((Class2.Excelcelldata(i, "Phone Number")));
		
		WebElement username = driver.findElement(By.xpath(Prop.getProperty("username")));
		username.sendKeys((Class2.Excelcelldata(i, "Username")));
		
		Select usergrp = new Select (driver.findElement(By.xpath(Prop.getProperty("usergroup"))));
		usergrp.selectByValue("2");
		
		WebElement address = driver.findElement(By.xpath(Prop.getProperty("add1")));
		address.sendKeys((Class2.Excelcelldata(i, "Address 1")));
		
		WebElement states = driver.findElement(By.xpath(Prop.getProperty("state")));
		states.click();
		List <WebElement> statedrop = driver.findElements(By.xpath(Prop.getProperty("statevalue")));
		for(int s=0; s<statedrop.size(); s++) {
			System.out.print("State= " + statedrop.get(s).getText());
			System.out.print("Print= " +  Class2.Excelcelldata(i, "State"));
			if(statedrop.get(s).getText().toString().equals(Class2.Excelcelldata(i, "State"))) {
				((WebElement) statedrop.get(s)).click();
				break;
 				}
			}
		WebElement city = driver.findElement(By.xpath(Prop.getProperty("city")));
		city.sendKeys((Class2.Excelcelldata(i, "City")));
		
		WebElement zipcode = driver.findElement(By.xpath(Prop.getProperty("zipcode")));
		zipcode.sendKeys((Class2.Excelcelldata(i, "Zip Code")));
		
		boolean checkbox = driver.findElement(By.xpath(Prop.getProperty("checkbox"))).isSelected();
		if(!checkbox) {
		WebElement checkbox1 = driver.findElement(By.xpath(Prop.getProperty("checkbox")));
		checkbox1.click();
		}
		
		WebElement radio = driver.findElement(By.xpath(Prop.getProperty("radio")));
		radio.click();
		
		WebElement TextArea = driver.findElement(By.xpath(Prop.getProperty("textarea")));
		TextArea.sendKeys((Class2.Excelcelldata(i, "Text area")));
		

		boolean payon = driver.findElement(By.xpath(Prop.getProperty("payonaccount"))).isEnabled();
			if(payon==true) {
			WebElement payontoggle = driver.findElement(By.xpath(Prop.getProperty("payonaccount")));
			payontoggle.click();
			}
		boolean payonlimit = driver.findElement(By.xpath(Prop.getProperty("payonimit"))).isDisplayed();
			if(payonlimit==true) {
			WebElement limit = driver.findElement(By.xpath(Prop.getProperty("payonimit")));
			limit.sendKeys(Class2.Excelcelldata(i, "Pay On Limit"));
			}
		WebElement saveback = driver.findElement(By.xpath(Prop.getProperty("saveandback")));
		saveback.click();
		}
	}
}

