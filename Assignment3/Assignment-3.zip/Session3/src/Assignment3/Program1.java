package Assignment3;

public class Program1 {

	public void addition() {
		int a=1; 
		int sum=0;
		while(a<=50) {
			if(a%2==0) { //for even number
				sum = sum + a;
			}
			a++;
		}
		System.out.println("Sum: " + sum);
	}
	
    public void sum() {
    	int a=1, sum=0;
    	for(int i = a;i<=50;i++) {
    		if(a%2==0) {  // for even number
    			sum = sum + a;
    		}
    		a++;
    	}
    	System.out.println("Addition " + sum);
    } 
	
	
	public static void main(String[] args) {
		Program1 Test = new Program1();
		Test.addition();
		Test.sum();
		}
}
