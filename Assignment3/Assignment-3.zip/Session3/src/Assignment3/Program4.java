package Assignment3;

import java.util.Scanner;

public class Program4 {

	public static void main(String[] args) {
		System.out.println("Enter Name");
		Scanner sc = new Scanner(System.in);
		String Fullname = sc.nextLine();
		System.out.println("Full name: " + Fullname);
		
		String [] Name = Fullname.split(" ");
		String Firstname = Name[0];
		String Middlename = Name[1];
		String Lastname = Name[2];
		if (Name.length == 3) {
		String abbreviation = Name[0].charAt(0) + "." + Name[1].charAt(0) + "." + Name [2];
		           System.out.println("Abbreviation: " + abbreviation);
		       }
	}
}
