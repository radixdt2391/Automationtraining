package Assignment3;

import java.util.Scanner;

public class Program2 {

	public static void main(String[] args) {
		
		System.out.println("Enter Product price length:");	
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		
		float[] Price = new float[n];
		int[] Quantity = new int [n];
		String[] Size = new String[n];
			for(int i=0;i<Price.length;i++) {
				System.out.println("Product Price is");	
				//float Price1 = sc.nextFloat();
				//int Quantity1 = sc.nextInt();
				//String Size1 = sc.next();	
			
				Price[i] = sc.nextFloat();
				Quantity[i] = sc.nextInt();
				Size[i] = sc.next();
		}		
			for(int i = 0; i < Price.length; i++){
				if(Price[i]==0) {
					continue;
				}
				if(Quantity[i] > 1000) {
					System.out.println("Not allow to order quantity greater than 1000");
					break;
				}
				System.out.println("Product " + (i + 1) + ", Price = $" + Price[i] +
	                    ", Quantity = " + Quantity[i] +
	                    ": Size = " + Size[i]);
        }
			public static Value(float Price, int Quantity) {
				return Price * Quantity;
			}
			

	}
}	
