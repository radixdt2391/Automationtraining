package Assignment3;

import java.util.ArrayList;
import java.util.Scanner;

public class Program3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Fname");
			ArrayList<String> A1 = new ArrayList<String>();
				for(int i=0;i<2;i++) {
				String Firstname = sc.next();
					A1.add(Firstname);
				}
					
				ArrayList<String> A2 = new ArrayList<String>();
					for(int j=0;j<2;j++) {
					String Lastname = sc.next();
					 	A2.add(Lastname);
					}
						System.out.println("First Name: " + A1);
						System.out.println("Last Name: " + A2);
						
						A1.addAll(A2);
							System.out.println("Full name: " + A1);
		}
	}

