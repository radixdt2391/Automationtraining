package Assignment4;

import java.util.Scanner;

class Bank {
	public float intrest(float P, float R, float T) {
		float Interest; 
		Interest = (P * T * R)/100;
		return Interest;
	}
}
	class SBI extends Bank {
	public float sbiintrest(float P, float R, float T) {
		float Interest; 
			Interest = (P * T * R)/100;
			return Interest;
	}
}
	class ICICI extends Bank {
		public float icicitrest (float P, float R, float T) {
			float Interest; 
			Interest = (P * T * R)/100;
			return Interest;
	}
}
	class AXIS extends Bank {
		public float axisintrest(float P, float R, float T) {
			float Interest; 
			Interest = (P * T * R)/100;
			return Interest;
	}
}
	public class Program2 {

		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
				System.out.println("Enter Amount: ");
			float P = sc.nextFloat();
				System.out.println("Enter Time: ");
			float T= sc.nextFloat();
				System.out.println("Enter Rate: ");
			float R= sc.nextFloat();
			
			SBI sbiint = new SBI();
			
			System.out.println("Enter Amount: ");
			float P1 = sc.nextFloat();
				System.out.println("Enter Time: ");
			float T1= sc.nextFloat();
				System.out.println("Enter Rate: ");
			float R1= sc.nextFloat();
			
			ICICI icicint = new ICICI();
			
			System.out.println("Enter Amount: ");
			float P2 = sc.nextFloat();
				System.out.println("Enter Time: ");
			float T2= sc.nextFloat();
				System.out.println("Enter Rate: ");
			float R2= sc.nextFloat();
			
			AXIS axisint = new AXIS ();
			
			System.out.println("SBI Intrest rate is: " + sbiint.sbiintrest(P, R, T));
			System.out.println("ICICI Intrest rate is: " + icicint.intrest(P1, R1, T1));
			System.out.println("AXIX Intrest rate is: " + axisint.axisintrest(P2, R2, T2));
		}

	}