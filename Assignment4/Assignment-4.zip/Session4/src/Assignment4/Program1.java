package Assignment4;

import java.util.Scanner;

abstract class Marks {
	
	public abstract double getPercentage();
}

	class studentA extends Marks {

			int studentmark1, studentmark2, studentmark3;

		public studentA (int mark1, int mark2, int mark3) {
			this.studentmark1 = mark1;
			this.studentmark2 = mark2;
			this.studentmark3 = mark3;
		}
		public double getPercentage () {
			float marks = studentmark1 + studentmark2 + studentmark3;
			return (marks/300)*100;
		}
	}

	class studentB extends Marks {

		int studentmark1, studentmark2, studentmark3, studentmark4;

		public studentB(int mark1, int mark2, int mark3, int mark4) {
			this.studentmark1 = mark1;
			this.studentmark2 = mark2;
			this.studentmark3 = mark3;
			this.studentmark4 = mark4;
		}
		public double getPercentage() {
			float marks = studentmark1 + studentmark2 + studentmark3 + studentmark4;
			return (marks/400)*100;
		}	
	}
		public class Program1 {
			public static void main(String[] args) {
				Scanner sc = new Scanner(System.in);
				System.out.println("Enter marks of Student A:");
				int i = sc.nextInt();
				int i1 = sc.nextInt();
				int i2= sc.nextInt();
		
				studentA Astud = new studentA(i, i1, i2);
		
				System.out.println("Enter marks of Student A:");
				int i3 = sc.nextInt();
				int i4 = sc.nextInt();
				int i5 = sc.nextInt();
				int i6 = sc.nextInt();
		
				studentB Bstud = new studentB(i3, i4, i5, i6);
			
					System.out.println("Percentage of Student A:" + Astud.getPercentage()+"%");
					System.out.println("Percentage of Student B:" + Bstud.getPercentage()+"%");

		}
}
