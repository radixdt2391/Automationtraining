import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.GeckoDriverService;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Program1 {
	
	static WebDriver driver;
	
	
	public static FirefoxDriver getFirefoxDriver() {
		FirefoxProfile fp = new FirefoxProfile();
		fp.setPreference("browser.helperApps.neverAsk.saveToDisk", "application/pdf, application/vnd.ms-excel, application/zip, multipart/x-zip, application/x-compressed, application/x-zip-compressed ");
		fp.setPreference("browser.download.manager.showWhenStarting", false);
		fp.setPreference("pdfjs.disabled", true);
        FirefoxOptions options = new FirefoxOptions();
        options.setProfile(fp);
        String osName = System.getProperty("os.name");
        String profileRoot = osName.contains("Linux") && new File("/snap/firefox").exists()? createProfileRootInUserHome(): null;
        return profileRoot != null? new FirefoxDriver(createGeckoDriverService(profileRoot), options): new FirefoxDriver(options);
    }
 
    private static String createProfileRootInUserHome() {
        String userHome = System.getProperty("user.home");
        File profileRoot = new File(userHome, "snap/firefox/common/.firefox-profile-root");
        if (!profileRoot.exists()) {
            if (!profileRoot.mkdirs()) {
                return null;
            }
        }
        return profileRoot.getAbsolutePath();
    }
 
    private static GeckoDriverService createGeckoDriverService(final String tempProfileDir) {
        return new GeckoDriverService.Builder() {
            @Override
            protected List<String> createArgs() {
                List<String> args = new ArrayList<>(super.createArgs());
                args.add(String.format("--profile-root=%s", tempProfileDir));
                return args;
            }
        }.build();
    }
	
	public static void main(String[] args) {
		
		System.out.println("Enter browser name");
		Scanner sc = new Scanner(System.in);
		String browser = sc.nextLine();
		
		
		
		if(browser.equalsIgnoreCase("Chrome")) {
		ChromeOptions handlingSSL = new ChromeOptions();
		handlingSSL.setAcceptInsecureCerts(true);
		driver = new ChromeDriver(handlingSSL); //for chrome browser
		}
		else if(browser.equalsIgnoreCase("Firefox")){
		WebDriverManager.firefoxdriver().setup();
		driver = getFirefoxDriver();
		}
		
		//WebDriver Driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.ops-s3.radixdev79.com/admin/index.php");
		WebElement login = driver.findElement(By.id("username"));
		login.sendKeys("admin");
		WebElement password = driver.findElement(By.id("password"));
		password.sendKeys("Admin095");
		WebElement click = driver.findElement(By.name("login"));
		click.click();
		driver.navigate().to("https://www.ops-s3.radixdev79.com/admin/user_listing.php");	
		driver.navigate().to("https://www.ops-s3.radixdev79.com/admin/user_action.php");
		
		WebElement Fname = driver.findElement(By.id("firstname"));
		Fname.sendKeys("Vids");
		WebElement Lname = driver.findElement(By.id("lastname"));
		Lname.sendKeys("Chauhan");
		WebElement email = driver.findElement(By.id("email"));
		email.sendKeys("test.qa1@radixweb.com");
		WebElement Password = driver.findElement(By.id("password"));
		Password.sendKeys("Admin@123");
		WebElement phoneno = driver.findElement(By.id("phone_number"));
		phoneno.sendKeys("8884445658");
		Select usergrp = new Select(driver.findElement(By.id("user_discount_group_id")));
		usergrp.selectByIndex(1);
		WebElement Add1 = driver.findElement(By.id("street_address"));
		Add1.sendKeys("439th Ave");
		WebElement City = driver.findElement(By.id("city"));
		City.sendKeys("Wickenburg");
		WebElement zipcode = driver.findElement(By.name("postcode"));
		zipcode.sendKeys("50809");
		WebElement payon = driver.findElement(By.id("payon"));
		payon.click();
		WebElement payonlimit = driver.findElement(By.name("pay_limit"));
		payonlimit.sendKeys("500000");
		WebElement save = driver.findElement(By.id("btn-action-saveback"));
		save.click();
		
	}
}
