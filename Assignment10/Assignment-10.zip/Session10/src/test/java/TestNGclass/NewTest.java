package TestNGclass;
 
import java.io.IOException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import Main.CreateCustomer;


public class NewTest {
	
	CreateCustomer user = new CreateCustomer();
	
  @BeforeTest
  public void browserload () {
	  user.browseropen();
  }
  
  @Test
  public void loggedin() throws IOException {
	  user.login();
  }
  @Test
  public void useradd() throws IOException {
	  user.adduser();
  }
  
  @Test
  public void useredit() throws IOException {
	  user.edituser();
  }
  
  @Test
  public void userdelete() throws IOException {
	  user.deleteuser();
  }
  
  @AfterTest
  public void browserclose () {
	  user.closebrowser();
  }
}
