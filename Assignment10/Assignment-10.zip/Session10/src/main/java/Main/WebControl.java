package Main;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class WebControl {
	
	public static void managetextbox(WebDriver driver, String value, String XPath) {
		WebElement input = driver.findElement(By.xpath(XPath));
		if(input.getAttribute("value")!=null) {
			input.clear();
		}
		input.sendKeys(value);
	}
	
	public static void manageclick (WebDriver driver, String Xpath) {
		WebElement clicks = driver.findElement(By.xpath(Xpath));
		clicks.click();	
	}
	
	public static void managedropdown (WebDriver driver, String Value, String XPath) {
		Select dropdown = new Select (driver.findElement(By.xpath(XPath)));
		dropdown.selectByValue(Value);
	}
	
	public static void bootstrapDD (WebDriver driver, String Value, String XPath) {
		List <WebElement> dropdown = driver.findElements(By.xpath(XPath));
		for(int i=0; i<dropdown.size(); i++) {
			System.out.println("Print state: " +  dropdown);
			if(dropdown.get(i).getText().toString().equals(Value)) {
				((WebElement) dropdown.get(i)).click();
				break;
 				}
			}
	}
}
