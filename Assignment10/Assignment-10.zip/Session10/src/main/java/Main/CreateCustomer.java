package Main;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

import com.fasterxml.jackson.databind.annotation.JsonAppend.Prop;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CreateCustomer {
	public static WebDriver driver;

	public static void capture (WebDriver driver, String filename) throws IOException {
		File scrshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrshot, new File(filename + "png"));
	}

	public void browseropen() {
		
		ChromeOptions handlingSSL = new ChromeOptions();
		handlingSSL.setAcceptInsecureCerts(true);
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver(handlingSSL); //for chrome browser
		driver.manage().window().maximize();
	}
	
	public String getXPath(String key) throws IOException {
		File propfile = new File ("src/test/resources/file.Properties");
		FileInputStream file = new FileInputStream(propfile);
		Properties Prop = new Properties();
		Prop.load(file);
		return Prop.getProperty(key);
	}
	
	
	public void login () throws IOException {
	
		driver.get("https://www.ops-s3.radixdev79.com/admin");
		WebControl.managetextbox(driver, "admin", getXPath("adminuser"));
		WebControl.managetextbox(driver, "Admin095", getXPath("adminpassword"));
		WebControl.manageclick(driver, getXPath("login"));
	
		CreateCustomer.capture(driver, "Login Page");	
	}
	
	public void adduser () throws IOException {
		
		driver.navigate().to("https://www.ops-s3.radixdev79.com/admin/user_listing.php");
		int Rowcount = ExcelData.Excelrowdata("Addcustom");
		System.out.println("Print row count " + Rowcount);
		
		for(int i=1;i<=Rowcount;i++) {
		
		WebControl.manageclick(driver, getXPath("addnew"));
		
		WebControl.managetextbox(driver, ExcelData.Excelcelldata(i, "First Name"), getXPath("firstname"));

		WebControl.managetextbox(driver, ExcelData.Excelcelldata(i, "Last Name"), getXPath("lastname"));

		WebControl.managetextbox(driver, ExcelData.Excelcelldata(i, "Email"), getXPath("email"));
	
		WebControl.managetextbox(driver, ExcelData.Excelcelldata(i, "Password"), getXPath("password"));
	
		WebControl.managetextbox(driver, ExcelData.Excelcelldata(i, "Phone Number"), getXPath("phonenumber"));
	
		WebControl.managetextbox(driver, ExcelData.Excelcelldata(i, "Username"), getXPath("username"));
		
		WebControl.managedropdown(driver, "2", getXPath("usergroup"));
//		Select usergrp = new Select (driver.findElement(By.xpath(getXPath("usergroup"))));
//		usergrp.selectByValue("2");
		
		CreateCustomer.capture(driver, "add-user");
		
		WebControl.managetextbox(driver, ExcelData.Excelcelldata(i, "Address 1"), getXPath("add1"));
	
		WebControl.manageclick(driver, getXPath("state"));
		WebControl.bootstrapDD(driver, ExcelData.Excelcelldata(i, "State"), getXPath("statevalue"));
//		List <WebElement> statedrop = driver.findElements(By.xpath(getXPath("statevalue")));
//		for(int s=0; s<statedrop.size(); s++) {
//			System.out.println("Print state: " +  statedrop);
//			if(statedrop.get(s).getText().toString().equals(ExcelData.Excelcelldata(i, "State"))) {
//				((WebElement) statedrop.get(s)).click();
//				break;
// 				}
//			}
		//System.out.println("Print Size: " + statedrop.size());
		
		WebControl.managetextbox(driver, ExcelData.Excelcelldata(i, "City"), getXPath("city"));
	
		WebControl.managetextbox(driver, ExcelData.Excelcelldata(i, "Zip Code"), getXPath("zipcode"));
	
		boolean checkbox = driver.findElement(By.xpath(getXPath("checkbox"))).isSelected();
		if(!checkbox) {
		WebControl.manageclick(driver,getXPath("checkbox"));
		}
		
		WebControl.manageclick(driver, getXPath("radio"));
		
		WebControl.managetextbox(driver, ExcelData.Excelcelldata(i, "Text area"), getXPath("textarea"));
	
		boolean payon = driver.findElement(By.xpath(getXPath("payonaccount"))).isEnabled();
			if(payon==true) {
			WebControl.manageclick(driver, getXPath("payonaccount"));
			}
			
		boolean payonlimit = driver.findElement(By.xpath(getXPath("payonimit"))).isDisplayed();
			if(payonlimit==true) {
			WebControl.managetextbox(driver, ExcelData.Excelcelldata(i, "Pay On Limit"), getXPath("payonimit"));
		}
		
		WebControl.manageclick(driver, getXPath("saveandback"));
		
		CreateCustomer.capture(driver, "user-added");
		}
	}
	
	public void edituser() throws IOException {
		
		WebControl.manageclick(driver, getXPath("action"));

		WebControl.manageclick(driver, getXPath("edit"));
		
		int EditRow = ExcelData.Excelrowdata("editcustom");
		for(int i=1;i<=EditRow;i++) {
		
		WebControl.managetextbox(driver, ExcelData.Excelcelldata(i, "First Name"), getXPath("firstname"));

		WebControl.managetextbox(driver, ExcelData.Excelcelldata(i, "Last Name"), getXPath("lastname"));

		WebControl.managetextbox(driver, ExcelData.Excelcelldata(i, "Phone Number"), getXPath("phonenumber"));

		CreateCustomer.capture(driver, "edit-user");
		
		WebControl.manageclick(driver, getXPath("saveandback"));
		}
	}
	
	public void deleteuser() throws IOException {
		WebControl.manageclick(driver, getXPath("action"));
		
		WebControl.manageclick(driver, getXPath("delete"));
		int time = 1;
		while(time<50000) {
			try {
			WebControl.manageclick(driver, getXPath("deleteok"));
			break;
			}
			catch (Exception e) {
			}
			time++;
		}
		driver.navigate().refresh();
		
		CreateCustomer.capture(driver, "delete-user");
	}

	public void closebrowser() {
		driver.close();
	}
}