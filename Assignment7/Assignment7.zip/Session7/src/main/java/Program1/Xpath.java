package Program1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Xpath {
	
	static WebDriver driver;

	public static void main(String[] args) {
		
		
		ChromeOptions handlingSSL = new ChromeOptions();
		handlingSSL.setAcceptInsecureCerts(true);
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver(handlingSSL); //for chrome browser
		
		driver.manage().window().maximize();
		driver.get("https://www.ops-s3.radixdev79.com/admin/index.php");
		WebElement login = driver.findElement(By.xpath("//input[@name='username']"));
		login.sendKeys("admin");
		WebElement password = driver.findElement(By.xpath("//input[@id='password']"));
		password.sendKeys("Admin095");
		WebElement click = driver.findElement(By.xpath("//button[@type='submit']"));
		click.click();
		driver.navigate().to("https://www.ops-s3.radixdev79.com/admin/user_listing.php");
		WebElement add = driver.findElement(By.xpath("//div[@id='actionButtons']//child::a[@class='btn btn-success btn-sm btn-sm ml-1 rounded']"));	
		add.click();
		WebElement Fname = driver.findElement(By.xpath("//div//child::input[@id='firstname']"));
		Fname.sendKeys("Vids");
		WebElement Lname = driver.findElement(By.xpath("//input[@id='lastname']"));
		Lname.sendKeys("Chauhan");
		WebElement email = driver.findElement(By.xpath("//input[contains(@data-msg-email,'email address')]"));
		email.sendKeys("test.qa1@radixweb.com");
		WebElement Password = driver.findElement(By.xpath("//input[@id='email']//following::input[@id='password']"));
		Password.sendKeys("Admin@123");
		WebElement phoneno = driver.findElement(By.xpath("//input[@id='username']//preceding::input[@id='phone_number']"));
		phoneno.sendKeys("8884445658");
		Select usergrp = new Select(driver.findElement(By.xpath("//select[@id='user_discount_group_id']")));
		usergrp.selectByIndex(1);
		WebElement Add1 = driver.findElement(By.xpath("//input[@id='street_address']"));
		Add1.sendKeys("439th Ave");
		WebElement City = driver.findElement(By.xpath("//input[@id='city']"));
		City.sendKeys("Wickenburg");
		driver.findElement(By.xpath("//button[@data-id='state']")).click();
		List <WebElement> dropdown_list = driver.findElements(By.xpath("//ul[@class='dropdown-menu inner show']/li"));
		
		for(int i=0; i<dropdown_list.size();i++) {
			if (dropdown_list.get(i).getText().equals("Arizona")) {
			((WebElement) dropdown_list.get(i)).click();
			break;
			}
		}
		boolean checkbox = driver.findElement(By.xpath("(//input[contains(@id,'checkbox')])[1]")).isSelected();
			if(!checkbox) {
			WebElement checkbox1 = driver.findElement(By.xpath("(//input[contains(@id,'checkbox')])[1]"));
			checkbox1.click();
			}
			
		WebElement radio = driver.findElement(By.xpath("//input[@class='profileclass form_field_28 ace' and @data-att-id='35']"));
		radio.click();
		WebElement textarea = driver.findElement(By.xpath("//textarea[contains(@class,'form-control  profileclass')]"));
		textarea.sendKeys("Test123");
		
		boolean payon = driver.findElement(By.xpath("//input[@name='payon' and @value='on']")).isEnabled();
			if(payon==true) {
			WebElement payontoggle = driver.findElement(By.xpath("//input[@name='payon' and @value='on']"));
			payontoggle.click();
			}
		boolean payonlimit = driver.findElement(By.xpath("//input[@name='pay_limit']")).isDisplayed();
			if(payonlimit==true) {
			WebElement limit = driver.findElement(By.xpath("//input[@name='pay_limit']"));
			limit.sendKeys("500000");
			}
		WebElement save = driver.findElement(By.xpath("//button[@id='btn-action-saveback' and @value='Save & Back']"));
		save.click();
	}
}
